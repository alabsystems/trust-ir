use super::*;

#[derive(Clone)]
pub(super) struct Inputs {
    pub model: MachineModel,
    pub memory: Expr,
    pub host: Expr,
    pub fuel: Expr,
}
impl Inputs {
    pub fn owner(&self) -> Expr {
        app("ir_byte_fresh_owner_v1", [self.memory.clone()])
    }
    pub fn world(&self) -> Expr {
        app(
            "IRByteWorldV1.mk",
            [
                self.model.world_type().clone(),
                self.memory.clone(),
                self.host.clone(),
                list("Nat", [self.owner()]),
                app("Nat.succ", [self.owner()]),
            ],
        )
    }
    pub fn memory_guard(&self) -> Expr {
        EntryTarget::memory_admission(self.memory.clone())
    }
    pub fn halted(&self, outcome: Expr, world: Expr) -> Expr {
        app(
            "IRByteConfigV1.halted",
            [self.model.world_type().clone(), outcome, world],
        )
    }
    pub fn bad(&self, fault: &str) -> Expr {
        self.halted(app("IROutcome.type_error", [c(fault)]), self.world())
    }
    pub fn run(&self, fuel: Expr, initial: Expr) -> Expr {
        app(
            "ir_byte_run_v1",
            [
                self.model.world_type().clone(),
                self.model.context().clone(),
                self.model.providers().clone(),
                fuel,
                initial,
            ],
        )
    }
    pub fn initial(&self, subject: &Subject<'_>, arguments: Expr) -> Expr {
        app(
            "ir_byte_init_v1",
            [
                self.model.world_type().clone(),
                self.model.context().clone(),
                nat(u64::from(subject.source.function().id.index())),
                arguments,
                self.memory.clone(),
                self.host.clone(),
            ],
        )
    }
    pub fn current(&self, subject: &Subject<'_>, arguments: Expr) -> Current {
        Current {
            frame: app(
                "IRFrame.mk",
                [
                    nat(u64::from(subject.source.function().id.index())),
                    nat(u64::from(subject.source.function().entry.index())),
                    nat(0),
                    app(
                        "ir_bind_params",
                        [
                            list(
                                "Nat",
                                subject.parameters.map(|id| nat(u64::from(id.index()))),
                            ),
                            arguments,
                            list("IRBinding", []),
                        ],
                    ),
                    list("Nat", []),
                ],
            ),
            tail: list("IRFrame", []),
            legacy_memory: list("IRMemSlot", []),
            legacy_cursor: nat(0),
            world: self.world(),
        }
    }
    pub fn returned(&self, value: Expr) -> Expr {
        let world = app(
            "IRByteWorldV1.mk",
            [
                self.model.world_type().clone(),
                app("ir_byte_retire_v1", [self.owner(), self.memory.clone()]),
                self.host.clone(),
                list("Nat", []),
                app("Nat.succ", [self.owner()]),
            ],
        );
        self.halted(
            app("IROutcome.ret", [list("IRScalar", [int(value)])]),
            world,
        )
    }
}

pub(super) fn states(subject: &Subject<'_>, input: &Inputs, x: Expr, y: Expr) -> Vec<Expr> {
    let mut current = input.current(subject, list("IRScalar", [int(x.clone()), int(y.clone())]));
    let mut result = vec![current.running(&input.model)];
    let mut values = BTreeMap::from([
        (subject.parameters[0], x.clone()),
        (subject.parameters[1], y.clone()),
    ]);
    for operation in &subject.operations {
        let (id, value) = match operation {
            Operation::Constant {
                destination,
                literal,
            } => (*destination, nat(*literal)),
            Operation::Add {
                destination,
                left,
                right,
            } => (
                *destination,
                fast(values[left].clone(), values[right].clone()),
            ),
        };
        current.frame = app(
            "ir_frame_advance",
            [app(
                "ir_frame_set_many",
                [
                    current.frame,
                    list("Nat", [nat(u64::from(id.index()))]),
                    list("IRScalar", [int(value.clone())]),
                ],
            )],
        );
        values.insert(id, value);
        result.push(current.running(&input.model));
    }
    result.push(input.returned(subject.denotation(x, y)));
    result
}

// A finite prefix lookup, with the final halted value for every larger fuel.
// This does not manufacture an OutOfFuel outcome for a partial running state.
pub(super) fn select(fuel: Expr, states: &[Expr], ty: Expr) -> Expr {
    if states.len() == 1 {
        return states[0].clone();
    }
    let n = Expr::bvar(1);
    // The two binders are predecessor and the unused recursive result.
    let tail = select(n, &states[1..], ty.clone());
    Expr::apps(
        Expr::const_(
            Name::from_string("Nat.rec"),
            vec![Level::succ(Level::zero())],
        ),
        [
            Expr::lam(BinderInfo::Default, c("Nat"), ty.clone()),
            states[0].clone(),
            Expr::lam(
                BinderInfo::Default,
                c("Nat"),
                Expr::lam(BinderInfo::Default, ty, tail),
            ),
            fuel,
        ],
    )
}

#[derive(Clone)]
struct Word {
    value: Expr,
    bound: PendingProof,
    denotation: Expr,
    equation: PendingEquality,
}
fn fits(
    assembler: &mut Assembler<'_>,
    model: &MachineModel,
    word: &Word,
) -> Result<PendingEquality> {
    let proof = app(
        "ir_byte_ltb_of_lt_v1",
        [word.value.clone(), limit(), word.bound.term().clone()],
    );
    let equality = PendingEquality::candidate(
        c("Bool"),
        app("ir_nat_ltb", [word.value.clone(), limit()]),
        c("Bool.true"),
        proof,
    );
    assembler.convert_endpoints(
        equality,
        app(
            "ir_byte_value_matches_v1",
            [
                model.context().clone(),
                app("IRTy.uint_", [nat(64)]),
                int(word.value.clone()),
            ],
        ),
        c("Bool.true"),
    )
}
fn both(
    assembler: &mut Assembler<'_>,
    a: PendingEquality,
    b: PendingEquality,
) -> Result<PendingEquality> {
    let first = mapped(assembler, a, c("Bool"), |flag| {
        app("Bool.and", [flag, b.left().clone()])
    })?;
    let second = mapped(assembler, b, c("Bool"), |flag| {
        app("Bool.and", [c("Bool.true"), flag])
    })?;
    let result = assembler.compose(first, second)?;
    assembler.convert_endpoints(result.clone(), result.left().clone(), c("Bool.true"))
}
fn constant_bound(value: u64) -> PendingProof {
    PendingProof::candidate(
        bound(nat(value)),
        app(
            "Nat.le_add_right",
            [app("Nat.succ", [nat(value)]), nat(u64::MAX - value)],
        ),
    )
}
fn add_word(assembler: &mut Assembler<'_>, a: &Word, b: &Word) -> Result<(Word, PendingEquality)> {
    let (_, evaluated, output_bound) = assembler.byte_add_u64_canonical(
        a.value.clone(),
        b.value.clone(),
        a.bound.clone(),
        b.bound.clone(),
    )?;
    let value = fast(a.value.clone(), b.value.clone());
    let first = mapped(assembler, a.equation.clone(), c("Nat"), |left| {
        den_add(left, b.denotation.clone())
    })?;
    let second = mapped(assembler, b.equation.clone(), c("Nat"), |right| {
        den_add(a.value.clone(), right)
    })?;
    let arguments = [
        nat(64),
        a.value.clone(),
        b.value.clone(),
        app(
            "ir_byte_ltb_of_lt_v1",
            [a.value.clone(), limit(), a.bound.term().clone()],
        ),
        app(
            "ir_byte_ltb_of_lt_v1",
            [b.value.clone(), limit(), b.bound.term().clone()],
        ),
    ];
    let modulus = PendingEquality::candidate(
        c("Nat"),
        den_add(a.value.clone(), b.value.clone()),
        value.clone(),
        app("RustSourceWord64IRV1.modCanonical", arguments),
    );
    let equation = assembler.compose(first, second)?;
    let equation = assembler.compose(equation, modulus)?;
    Ok((
        Word {
            value,
            bound: output_bound,
            denotation: den_add(a.denotation.clone(), b.denotation.clone()),
            equation,
        },
        evaluated,
    ))
}

// One scalar chain, all premises derived from the two input canonical bounds
// and actual initialization. No operation answer or run-success hypothesis.
pub(super) fn successful(
    subject: &Subject<'_>,
    environment: &Environment,
    assembler: &mut Assembler<'_>,
    input: &Inputs,
    x: Expr,
    y: Expr,
    hx: PendingProof,
    hy: PendingProof,
    memory: PendingEquality,
) -> Result<(Vec<Expr>, Vec<PendingEquality>)> {
    let model = &input.model;
    let mut catalog = Catalog::new(environment, &subject.reflected, subject.limits)?;
    let entry = catalog.entry(subject.source.function().id)?;
    let target = catalog.call_target(subject.source.function().id)?;
    let arguments = list("IRScalar", [int(x.clone()), int(y.clone())]);
    let mut words = BTreeMap::from([
        (
            subject.parameters[0],
            Word {
                value: x.clone(),
                bound: hx,
                denotation: x.clone(),
                equation: pending(c("Nat"), x.clone()),
            },
        ),
        (
            subject.parameters[1],
            Word {
                value: y.clone(),
                bound: hy,
                denotation: y.clone(),
                equation: pending(c("Nat"), y.clone()),
            },
        ),
    ]);
    let xfits = fits(assembler, model, &words[&subject.parameters[0]])?;
    let yfits = fits(assembler, model, &words[&subject.parameters[1]])?;
    let ylist = both(assembler, yfits, pending(c("Bool"), c("Bool.true")))?;
    let admitted = both(assembler, xfits, ylist)?;
    let admitted = assembler.convert_endpoints(
        admitted,
        entry.admission(model, arguments.clone())?,
        c("Bool.true"),
    )?;
    let initialized = entry.initialize(
        assembler,
        model,
        arguments,
        input.memory.clone(),
        input.host.clone(),
        memory,
        admitted,
    )?;
    let mut current = input.current(subject, list("IRScalar", [int(x.clone()), int(y.clone())]));
    let initialized_equation = assembler.convert_endpoints(
        initialized.equality().clone(),
        initialized.equality().left().clone(),
        current.running(model),
    )?;
    let mut validity = assembler.convert_endpoints(
        initialized.valid().clone(),
        current.valid(model),
        c("Bool.true"),
    )?;
    let mut all_states = vec![current.running(model)];
    let mut steps = Vec::new();
    for (pc, operation) in subject.operations.iter().enumerate() {
        let site = catalog.fetch(Coordinate {
            function: subject.source.function().id,
            block: subject.source.function().entry,
            instruction: pc,
        })?;
        let (destination, word, add_evaluated) = match operation {
            Operation::Constant {
                destination,
                literal,
            } => {
                let bound = constant_bound(*literal);
                let denotation = nat(*literal);
                let equation = pending(c("Nat"), denotation.clone());
                (
                    *destination,
                    Word {
                        value: nat(*literal),
                        bound,
                        denotation,
                        equation,
                    },
                    None,
                )
            }
            Operation::Add {
                destination,
                left,
                right,
            } => {
                let (word, proof) = add_word(assembler, &words[left], &words[right])?;
                (*destination, word, Some(proof))
            }
        };
        let checks = site.scalar_checks(model, &current, int(word.value.clone()))?;
        let output_fits = fits(assembler, model, &word)?;
        let result = both(
            assembler,
            output_fits.clone(),
            pending(c("Bool"), c("Bool.true")),
        )?;
        let result = assembler.convert_endpoints(result, checks.result.clone(), c("Bool.true"))?;
        let (evaluated, operands) = match operation {
            Operation::Add { left, right, .. } => {
                let evaluated = assembler.convert_endpoints(
                    add_evaluated.unwrap(),
                    checks.evaluation.clone(),
                    app("IRStepResult.value", [int(word.value.clone())]),
                )?;
                let af = fits(assembler, model, &words[left])?;
                let bf = fits(assembler, model, &words[right])?;
                let operands = both(assembler, af, bf)?;
                (
                    evaluated,
                    assembler.convert_endpoints(
                        operands,
                        checks.operands.clone(),
                        c("Bool.true"),
                    )?,
                )
            }
            Operation::Constant { .. } => (
                assembler.conversion(
                    c("IRStepResult"),
                    checks.evaluation.clone(),
                    app("IRStepResult.value", [int(word.value.clone())]),
                )?,
                truth(assembler, checks.operands.clone())?,
            ),
        };
        let transferred = site.scalar_value(
            assembler,
            model,
            &current,
            int(word.value.clone()),
            ScalarPremises {
                evaluated,
                operands,
                result,
                before: validity,
            },
        )?;
        steps.push(transferred.step().clone());
        current = transferred.current().clone();
        validity = transferred.valid().clone();
        words.insert(destination, word);
        all_states.push(current.running(model));
    }
    let word = &words[&subject.returned];
    let returning = catalog.fetch(Coordinate {
        function: subject.source.function().id,
        block: subject.source.function().entry,
        instruction: subject.operations.len(),
    })?;
    let frame = RootReturnFrame {
        returning: current.frame.clone(),
        legacy_memory: current.legacy_memory.clone(),
        legacy_cursor: current.legacy_cursor.clone(),
        memory: input.memory.clone(),
        host: input.host.clone(),
        owner: input.owner(),
        next: app("Nat.succ", [input.owner()]),
    };
    let values = list("IRScalar", [int(word.value.clone())]);
    let resolved = assembler.conversion(
        app("IRList", [c("IRScalar")]),
        app(
            "ir_resolve",
            [
                current.machine(),
                list("Nat", [nat(u64::from(subject.returned.index()))]),
            ],
        ),
        values.clone(),
    )?;
    let fit = fits(assembler, model, word)?;
    let fit = both(assembler, fit, pending(c("Bool"), c("Bool.true")))?;
    let fit = both(assembler, fit, pending(c("Bool"), c("Bool.true")))?;
    let admitted = assembler.convert_endpoints(
        fit,
        returning.root_return_admission(model, &target, &frame, values)?,
        c("Bool.true"),
    )?;
    let returned = returning.return_from_root(
        assembler, model, &target, &frame, resolved, admitted, validity,
    )?;
    let final_map = mapped(
        assembler,
        symm(&word.equation),
        model.config_type(),
        |value| input.returned(value),
    )?;
    let one = assembler.compose(returned.run().equality().clone(), final_map)?;
    // return_from_root exports run-one; a running head makes it exactly step.
    let one = assembler.convert_endpoints(
        one,
        model.step(current.running(model)),
        input.returned(word.denotation.clone()),
    )?;
    steps.push(one);
    all_states.push(input.returned(word.denotation.clone()));
    let expected = states(subject, input, x, y);
    if all_states != expected {
        return Err("operational prefix reconstruction disagrees".into());
    }
    // Initialization equality is prepended for the caller, not a fuel step.
    let mut equations = vec![initialized_equation];
    equations.extend(steps);
    Ok((all_states, equations))
}

pub(super) fn run_prefix(
    assembler: &mut Assembler<'_>,
    input: &Inputs,
    fuel: Expr,
    states: &[Expr],
    steps: &[PendingEquality],
) -> Result<PendingEquality> {
    let ty = input.model.config_type();
    let left = input.run(fuel.clone(), states[0].clone());
    let right = select(fuel.clone(), states, ty.clone());
    if states.len() == 1 {
        let args = states[0].get_app_args();
        return Ok(PendingEquality::candidate(
            ty,
            left,
            right,
            app(
                "ir_byte_run_halted_v1",
                [
                    input.model.world_type().clone(),
                    input.model.context().clone(),
                    input.model.providers().clone(),
                    args[1].clone(),
                    args[2].clone(),
                    fuel,
                ],
            ),
        ));
    }
    let n = assembler.local(c("Nat"))?;
    let predecessor = run_prefix(
        assembler,
        input,
        n.term().clone(),
        &states[1..],
        &steps[1..],
    )?;
    let mapped = mapped(assembler, steps[0].clone(), ty.clone(), |state| {
        input.run(n.term().clone(), state)
    })?;
    let next = assembler.compose(mapped, predecessor)?;
    let next = assembler.convert_endpoints(
        next,
        input.run(app("Nat.succ", [n.term().clone()]), states[0].clone()),
        select(app("Nat.succ", [n.term().clone()]), states, ty.clone()),
    )?;
    let k = assembler.local(c("Nat"))?;
    let motive = k.lam(eq(
        ty.clone(),
        input.run(k.term().clone(), states[0].clone()),
        select(k.term().clone(), states, ty.clone()),
    ));
    let ih = assembler.local(eq(
        ty.clone(),
        input.run(n.term().clone(), states[0].clone()),
        select(n.term().clone(), states, ty.clone()),
    ))?;
    let base = app("Eq.refl", [ty.clone(), states[0].clone()]);
    let proof = Expr::apps(
        Expr::const_(Name::from_string("Nat.rec"), vec![Level::zero()]),
        [motive, base, n.lam(ih.lam(next.term().clone())), fuel],
    );
    Ok(PendingEquality::candidate(ty, left, right, proof))
}
